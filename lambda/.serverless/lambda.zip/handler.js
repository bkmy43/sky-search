'use strict';

let pgp = require('pg-promise')();

const config = {
  user: 'root', //env var: PGUSER
  database: 'skyline_zalando', //env var: PGDATABASE
  password: '#P(*fhq3j(F#$:fo4pojf34fwe))', //env var: PGPASSWORD
  host: 'skyline-zalando.cycadpn5lmbi.eu-central-1.rds.amazonaws.com', // Server hosting the postgres database
  port: 5432, //env var: PGPORT
  max: 10, // max number of clients in the pool
  idleTimeoutMillis: 30000, // how long a client is allowed to remain idle before being closed
};

let db = pgp(config);


module.exports.hello = (event, context, callback) => {
  // const response = {
  //   statusCode: 200,
  //   body: JSON.stringify({a: '123'}),
  // };
  // callback(null, response);

  db.query('select * from items where id = ${id}', {id: event.path.id})
    .then( (res) => {
      console.log(res);
      const response = {
        statusCode: 200,
        body: JSON.stringify({a: 3}),
      };
      callback(null, response);
    })
    .catch( (err) => {
      console.log(err);
      callback(err);
    });
};
